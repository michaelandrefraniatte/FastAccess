const sendMessageId = document.getElementById("link");
if (sendMessageId) {
  sendMessageId.click();
}